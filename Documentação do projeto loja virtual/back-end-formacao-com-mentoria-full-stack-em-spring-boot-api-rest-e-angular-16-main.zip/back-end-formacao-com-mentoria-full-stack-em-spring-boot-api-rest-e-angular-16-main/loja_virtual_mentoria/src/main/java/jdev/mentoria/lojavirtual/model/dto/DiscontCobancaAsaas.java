package jdev.mentoria.lojavirtual.model.dto;

public class DiscontCobancaAsaas {
	
	private float value;
	private float dueDateLimitDays;
	public float getValue() {
		return value;
	}
	public void setValue(float value) {
		this.value = value;
	}
	public float getDueDateLimitDays() {
		return dueDateLimitDays;
	}
	public void setDueDateLimitDays(float dueDateLimitDays) {
		this.dueDateLimitDays = dueDateLimitDays;
	}
	
	
	
	
	

}
