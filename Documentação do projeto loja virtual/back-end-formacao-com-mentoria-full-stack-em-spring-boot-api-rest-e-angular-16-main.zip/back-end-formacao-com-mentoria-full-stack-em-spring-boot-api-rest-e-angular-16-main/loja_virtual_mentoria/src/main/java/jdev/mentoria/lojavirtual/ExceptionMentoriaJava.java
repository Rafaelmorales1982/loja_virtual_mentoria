package jdev.mentoria.lojavirtual;

public class ExceptionMentoriaJava extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ExceptionMentoriaJava(String msgErro) {
		super(msgErro);
	}

}
