package jdev.mentoria.lojavirtual.model.dto;

public class ObejtoMsgGeral {
	
	private String msg;
	
	public ObejtoMsgGeral(String msg) {
		this.msg = msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getMsg() {
		return msg;
	}

}
