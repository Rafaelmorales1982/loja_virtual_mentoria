package jdev.mentoria.lojavirtual.model.dto;

import java.io.Serializable;

public class ExtraDTO  implements Serializable{

	private static final long serialVersionUID = 1L;

}
