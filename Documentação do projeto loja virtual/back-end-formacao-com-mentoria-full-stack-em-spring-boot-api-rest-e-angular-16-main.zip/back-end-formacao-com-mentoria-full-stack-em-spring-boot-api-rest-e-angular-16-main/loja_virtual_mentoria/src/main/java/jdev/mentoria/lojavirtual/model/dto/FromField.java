package jdev.mentoria.lojavirtual.model.dto;

public class FromField {

	private String fromFieldId;

	// Getter Methods

	public String getFromFieldId() {
		return fromFieldId;
	}

	// Setter Methods

	public void setFromFieldId(String fromFieldId) {
		this.fromFieldId = fromFieldId;
	}

}
