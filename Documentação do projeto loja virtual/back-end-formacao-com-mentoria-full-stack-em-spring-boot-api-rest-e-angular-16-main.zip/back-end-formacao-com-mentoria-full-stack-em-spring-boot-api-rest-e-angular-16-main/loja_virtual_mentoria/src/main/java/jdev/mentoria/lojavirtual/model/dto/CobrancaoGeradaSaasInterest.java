package jdev.mentoria.lojavirtual.model.dto;

public class CobrancaoGeradaSaasInterest {

	private Double value;
	private String type;

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
