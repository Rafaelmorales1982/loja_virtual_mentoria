package jdev.mentoria.lojavirtual.model.dto;

public class FineConbrancaAsaas {
	
	private float value;
	
	public void setValue(float value) {
		this.value = value;
	}
	public float getValue() {
		return value;
	}

}
