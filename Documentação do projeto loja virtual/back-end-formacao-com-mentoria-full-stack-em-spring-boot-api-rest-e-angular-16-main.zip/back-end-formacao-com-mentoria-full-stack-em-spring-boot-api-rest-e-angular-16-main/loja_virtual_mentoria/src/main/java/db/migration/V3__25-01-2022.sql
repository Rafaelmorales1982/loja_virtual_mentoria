ALTER TABLE pessoa_fisica ADD COLUMN tipo_pessoa character varying(255);
ALTER TABLE pessoa_juridica ADD COLUMN tipo_pessoa character varying(255);